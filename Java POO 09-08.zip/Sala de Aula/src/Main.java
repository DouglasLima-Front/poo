public class Main {
    public static void main (String[]args){
        Sala b201 = new Sala();
        b201.qtdcomputador = 50;
        b201.numerodasala = "B201";
        b201.qtdalunos = 22;

        System.out.println(b201.qtdcomputador);
        System.out.println(b201.numerodasala);
        System.out.println(b201.qtdalunos);
    }
}
