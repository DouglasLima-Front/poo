public class Sala {
    int qtdcomputador;
    String numerodasala;
    int qtdalunos;
}
